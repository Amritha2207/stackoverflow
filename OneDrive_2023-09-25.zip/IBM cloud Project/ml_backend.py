import re
from bs4 import BeautifulSoup
import requests
import string
import pickle
import numpy as np
import requests


def renew_token():
	API_KEY = "vxxDfSKM6U84zKP71ZWl0T2L4HeITjQLtV5lzVbXKU4u"
	global mltoken
	token_response = requests.post('https://iam.cloud.ibm.com/identity/token', data={"apikey":
	API_KEY, "grant_type": 'urn:ibm:params:oauth:grant-type:apikey'})
	mltoken = token_response.json()["access_token"]
	header = {'Content-Type': 'application/json', 'Authorization': 'Bearer ' + mltoken}

renew_token()	
	

def svc(payload_scoring):
	response_scoring = requests.post('https://us-south.ml.cloud.ibm.com/ml/v4/deployments/d46ed297-5fe9-4e85-9aec-bd06b0000b2b/predictions?version=2021-05-01', json=payload_scoring,
 headers={'Authorization': 'Bearer ' + mltoken})
	return response_scoring
		
	
def clean_text(text):
	text = BeautifulSoup(text, features="html.parser").get_text()
	text = re.sub("[^a-zA-Z]", " ", text)
	text = text.lower()
	tokens = text.split()
	return " ".join(tokens)

multilabel = pickle.load(open("static/multi_label.pkl", 'rb'))


def choose_model(payload_scoring):
	response_scoring = svc(payload_scoring)

	response_data = response_scoring.json()
	original_predictions = response_data
	values = original_predictions['predictions'][0]['values'][0][0]
	numpy_array = np.array(values)
	desired_shape = (1, -1)
	reshaped_array = numpy_array.reshape(desired_shape)
	output = multilabel.inverse_transform(reshaped_array)
	return output[0]
    

def predict_tags(question, description):
	description = clean_text(description)
	x1 = [question]
	x2 = [question + " " + description]

	payload_scoring_que = {"input_data": [{"field": [x1], "values": [x1]}]}
	payload_scoring_desc = {"input_data": [{"field": [x2], "values": [x2]}]}
	
	tags = choose_model(payload_scoring_que)
	if description:
		tags2 = choose_model(payload_scoring_desc)
		tags = list(set(tags) | set(tags2))
	return tags
	

# Function to search Stack Overflow and get relevant question links
def search_stack_overflow(tags):
    base_url = "https://api.stackexchange.com/2.3/search/advanced"
    params = {
        "order": "desc",
        "sort": "votes",
        "q": " ".join(tags),
        "site": "stackoverflow"}

    response = requests.get(base_url, params=params)
    data = response.json()

    question_links = []
    for item in data.get("items", []):
        question_links.append(item["link"])

    return question_links


# Function to update visit count in the session
def update_visit_count(session):
    # Initialize visit count if not present in session
    if 'visit_count' not in session:
        session['visit_count'] = 0
    
    # Increment visit count
    session['visit_count'] += 1

